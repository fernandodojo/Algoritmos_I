function boolean(b)
	if b then
		b = false
	else
		b = true
	end
	return b
end